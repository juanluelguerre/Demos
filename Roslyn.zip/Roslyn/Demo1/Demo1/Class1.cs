
class Foo 
{ 
  int Bar => 42; 
}
